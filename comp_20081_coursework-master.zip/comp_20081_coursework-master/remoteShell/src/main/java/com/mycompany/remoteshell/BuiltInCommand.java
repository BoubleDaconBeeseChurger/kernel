/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.remoteshell;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *
 * @author ntu-user
 */
public class BuiltInCommand {
    String[] validCommands = new String[] {"super", "addUser", "delUser", "chPass", "chUserType", "whoAmI", "move", "copy", "login", "logoff", "cd", "showDir", "help"};
    
    public BuiltInCommand(String command, String[] arguments, Session session, User user) throws IOException {
        switch (command) {
            case "super" -> superCommands(arguments[1], arguments, session, user);
            case "addUser" -> session.setCurrentOutput("Requires super command.");   //super
            case "delUser" -> session.setCurrentOutput("Requires super command.");   //super
            case "chPass" -> chPass(arguments[1], arguments[2], session, user); // current pass, new pass
            case "chUserType" -> session.setCurrentOutput("Requires super command");   //super
            case "whoAmI" -> whoAmI(user, session);
            case "move" -> move(arguments[1], arguments[2], session);
            case "copy" -> copy(arguments[1], arguments[2], session);
            case "login" -> login(arguments[1], arguments[2], session, user);
            case "logoff" -> logoff(session, user); //need to add file saving(each user has unique dir)
            case "help" -> help(session);
            case "cd" -> cd(arguments[1], session);
            case "showDir" -> showDir(session);
            case "showUsers" -> session.setCurrentOutput("Requires super command");   //super
        }
    }
    
    public void superCommands(String command, String[] arguments, Session session, User user) {
        if (user.isSuper) {
            switch (command) {
                case "delUser" -> delUser(arguments[2], session, user);
                case "chUserType" -> chUserType(arguments[2], session, user);
                case "addUser" -> addUser(arguments[2], arguments[3], session); //create unique dir and adds to DB
                case "showUsers" -> showUsers(session);
            }
        } else {
            session.setCurrentOutput("You do not have super permission.");
        }
        
    }
    
    public static void showUsers(Session session) {
        mySQLDB.getAllUsers(session);
    }
    
    public static void addUser(String user, String password, Session session) {
        try{
           new File("/home/ntu-admin/remoteshell/"+user).mkdirs();
            mySQLDB.addDataToDB(user, mySQLDB.encodePassword(password), session); 
        }
        catch (Exception e) {
            session.setCurrentOutput("Error: Unable to add user.");
        }
    }
    
    public static void chPass(String currentPass, String newPass, Session session, User user) {
        try {
            if (user.password.equals(currentPass)) {
                mySQLDB.setPassword(user.username, mySQLDB.encodePassword(newPass));
            } else {
                session.setCurrentOutput("Incorrect Password.");
            }
        }
        catch (Exception e) {
            session.setCurrentOutput("Error: Unable to change password.");
        }
    }
    
    public static void chUserType(String username, Session session, User user) {
        try {
            User target = mySQLDB.getRecordFromDB(username);
            if (target.isSuper) {
                
                mySQLDB.setSuper(username, false);
            } else {
                mySQLDB.setSuper(username, true);
            }
        }
        catch (Exception e) {
            session.setCurrentOutput("Error: Unable to change user type.");
        }
    }
    
    public static void logoff(Session session, User user) {
        try {
            //need to add some sort of file saving thing here
            
            user.username = "guest";
            user.password = "";
            user.isSuper = false;
            
            session.user = user;
            session.currentLocation = "/home/ntu-admin/"+user.username;
        }
        catch (Exception e) {
            session.setCurrentOutput("Error: Failed to log off.");
        }
    }
    
    public static void delUser(String targetUser, Session session, User user) {
        if (user.isSuper) {
            mySQLDB.delRecord(targetUser, session);
        }
        else {
            session.setCurrentOutput("Error: Super permission is required.");
        }
    }
    
    public static void whoAmI(User user, Session session) {
        session.setCurrentOutput(user.username);
    }
    
    public static void cd(String target, Session session) {
        if(target.equals("..")) {
            if (session.currentLocation.equals("/home/ntu-admin/remoteshell/"+session.user.username)) {
                session.setCurrentOutput("Error: Users can only access their directory.");
            } else {
                System.out.println(session.currentLocation);
                session.currentLocation = new File(session.currentLocation).getParent();
                System.out.println(session.currentLocation);
            }
        }
        else {
            File f = new File(session.currentLocation+"/"+target);
            if (f.isDirectory()) {
                session.currentLocation = session.currentLocation+"/"+target;
            }
            else {
                session.setCurrentOutput("Directory does not exist.");
                System.out.println(session.currentLocation+"/"+target);
            }
        } 
    }
    
    public static void showDir(Session session) {
        session.setCurrentOutput(session.currentLocation);
    }
    
    public static void copy(String sourceFile, String targetFile, Session session) {        
        File source = new File(session.currentLocation+"/"+sourceFile);
        File target = new File(session.currentLocation+"/"+targetFile);
        
        try (InputStream is = new FileInputStream(source);
        OutputStream os = new FileOutputStream(target);){
            byte[] buffer = new byte[1024];
            int length;
            
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
            session.setCurrentOutput("Copying "+sourceFile+" to "+targetFile);
            
            is.close();
            os.close();
        }
        catch (IOException e) {
            session.setCurrentOutput("Error: Failed to copy file.");
        }
    }
    
    public static void move(String sourceFile, String targetFile, Session session) {
        try {
            File source = new File(session.currentLocation+"/"+sourceFile);
            source.renameTo(new File(session.currentLocation+"/"+targetFile));
            session.setCurrentOutput("Moving "+sourceFile+" to "+targetFile);
        }
        catch (Exception e) {
            session.setCurrentOutput("Error: Failed to move file.");
        }
    }
    
    public static void login(String username, String password, Session session, User user) {
        try {
            if (mySQLDB.validateUser(username, password)) {
                user.username = username;
                user.password = password;
                user.isSuper = mySQLDB.getRecordFromDB(username).isSuper;
                
                session.user = user;
                session.currentLocation = "/home/ntu-admin/remoteshell/"+user.username;
            }
            else {
                session.setCurrentOutput("Error: Failed to log in.");
            }
        }
        catch (Exception e) {
            session.setCurrentOutput("Error: Failed to log in.");
        }
    }
    
    public void help(Session session) throws IOException {
        try {
            String helpFile = Files.readString(Path.of("/home/ntu-admin/remoteshell/help.txt"));
            session.setCurrentOutput(helpFile);
        }
        catch(FileNotFoundException e) {
            session.setCurrentOutput("Error: Failed to read help file.");
        }
    }
}
