/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.remoteshell;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.List;
import java.util.regex.Pattern;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ntu-admin
 */
public class mainTest {
    
    public mainTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }

    /**
     * Test of validateToken method, of class main.
     */
    @Test
    public void testValidateToken() {
        System.out.println("validateToken");
        String token = "";
        String[] dataset = null;
        boolean expResult = false;
        boolean result = main.validateToken(token, dataset);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of filterPath method, of class main.
     */
    @Test
    public void testFilterPath() {
        System.out.println("filterPath");
        String inputtedPath = "";
        String expResult = "";
        String result = main.filterPath(inputtedPath);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of filterPost method, of class main.
     */
    @Test
    public void testFilterPost() {
        System.out.println("filterPost");
        String inputtedPost = "";
        String expResult = "";
        String result = main.filterPost(inputtedPost);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of formatTerminalLine method, of class main.
     */
    @Test
    public void testFormatTerminalLine() {
        System.out.println("formatTerminalLine");
        String user = "";
        String dirPath = "";
        String command = "";
        String expResult = "";
        String result = main.formatTerminalLine(user, dirPath, command);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnListValue method, of class main.
     */
    @Test
    public void testReturnListValue() {
        System.out.println("returnListValue");
        List<String> copyList = null;
        List<String> expResult = null;
        List<String> result = main.returnListValue(copyList);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnStringValue method, of class main.
     */
    @Test
    public void testReturnStringValue() {
        System.out.println("returnStringValue");
        String copyString = "";
        String expResult = "";
        String result = main.returnStringValue(copyString);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of refreshHTTP method, of class main.
     */
    @Test
    public void testRefreshHTTP() {
        System.out.println("refreshHTTP");
        PrintWriter out = null;
        Session currentSession = null;
        main.refreshHTTP(out, currentSession);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPostData method, of class main.
     */
    @Test
    public void testGetPostData() throws Exception {
        System.out.println("getPostData");
        BufferedReader reader = null;
        String expResult = "";
        String result = main.getPostData(reader);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of allCharsValid method, of class main.
     */
    @Test
    public void testAllCharsValid() {
        System.out.println("allCharsValid");
        String[] parsedInput = null;
        Pattern invalidChars = null;
        Session session = null;
        Boolean expResult = null;
        Boolean result = main.allCharsValid(parsedInput, invalidChars, session);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class main.
     */
    @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        main.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
