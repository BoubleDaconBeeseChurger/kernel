/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.remoteshell;

import java.util.Vector;

/**
 *
 * @author ntu-admin
 */
public class History {
    String user;
    String location;
    String command;
    String output;
    
    public History(String user, String location, String command, String output) {
        this.user = user;
        this.location = location; 
        this.command = command;
        this.output = output;
    }
    
    public String getTerminalLine() {
        return(this.user + ":~" + location + "$ " + command);
    }
    
    public String getTerminalOutput() {
        return this.output;
    }
}
