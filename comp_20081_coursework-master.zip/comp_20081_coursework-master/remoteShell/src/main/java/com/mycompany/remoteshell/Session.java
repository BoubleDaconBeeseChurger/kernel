/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.remoteshell;

import java.util.Vector;

/**
 *
 * @author ntu-user
 */
public class Session {
    User user;
    String currentLocation = "";
    Vector<History> history;
    
    String currentOutput="";
    
    public void addToHistory(String user, String location, String command) {
        History newRecord = new History(user, location, command, this.currentOutput);
        this.history.add(newRecord);
    }
    
    public Session(User user) {
        this.user = user;
        this.currentLocation = "/home/ntu-admin/remoteshell/"+user.username;
        this.history = new Vector<>();
    };
    
    public void setCurrentOutput(String output) {
        this.currentOutput = output;
    }
}
