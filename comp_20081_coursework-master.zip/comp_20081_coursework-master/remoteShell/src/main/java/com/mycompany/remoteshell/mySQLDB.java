/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.remoteshell;

import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

/**
 *
 * @author ntu-admin
 */
public class mySQLDB {
    
    static private String dataBaseName="COMP20081";
    static private String dataBaseTableName="Users";
    static private String userName="admin";
    static private String userPassword="V7mihMWmkicF";
    static private String port="3306";
    static private String ip="localhost";
    static Connection conn = null;
    static PreparedStatement prepareStat = null;
    
    /**
    * @brief encode password method
    * @param[in] plain password of type String
    * @return encoded password of type String
    */
    public static String encodePassword(String plainPassword){
        byte[] bPass = plainPassword.getBytes(StandardCharsets.UTF_8);
        byte[] passBase64 = Base64.getEncoder().encode(bPass);
        String encodedPassword = new String(passBase64, StandardCharsets.UTF_8);
        return encodedPassword;
    }
    
    /**
    * @brief  decode password method
    * @param[in] encoded password of type String
    * @return decoded password of type String
    */
    public static String decodePassword(String encodedPassword){
        String decodedString = new String(Base64.getDecoder().decode(encodedPassword));
        return decodedString;
    }
    
    public static void setPassword(String user, String newPass) {
        try {
            String insertQueryStatement = "UPDATE Users SET `Password` = '"+newPass+"' WHERE User = '"+user+"';";
            System.out.println(insertQueryStatement);
            
            prepareStat = conn.prepareStatement(insertQueryStatement);

            prepareStat.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
    * @brief connect to the database method
    */
    public static void makeJDBCConnection() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            log("Congrats - Seems your MySQL JDBC Driver Registered!");
        } catch (ClassNotFoundException e) {
            log("Sorry, couldn't found JDBC driver. Make sure you have added JDBC Maven Dependency Correctly");
            e.printStackTrace();
            return;
        }

        try {
            // DriverManager: The basic service for managing a set of JDBC drivers.
            conn = DriverManager.getConnection("jdbc:mysql://"+ip+":"+port+"/"+dataBaseName+"?useSSL=false", userName, userPassword);
            if (conn != null) {
                log("Connection Successful! Enjoy. Now it's time to push data");
            } else {
                log("Failed to make connection!");
            }
        } catch (SQLException e) {
            log("MySQL Connection Failed!");
            e.printStackTrace();
            return;
        }

    }
    
    public static void getAllUsers(Session session) {
        try {
            String getQueryStatement = "SELECT User FROM Users";

            prepareStat = conn.prepareStatement(getQueryStatement);

            // Execute the Query, and get a java ResultSet
            ResultSet rs = prepareStat.executeQuery();
            
            String allUsers = "";
            
            while (rs.next()) {
                String user = rs.getString("User");
                allUsers = allUsers + " " + user;
            }
            
            session.setCurrentOutput(allUsers);
        
        } catch (SQLException e) {
            e.printStackTrace();
        }  
    }
    
    public static void delRecord(String user, Session session) {
        try {
            String insertQueryStatement = "DELETE FROM "+dataBaseTableName+" WHERE User='"+user+"'";
            
            prepareStat = conn.prepareStatement(insertQueryStatement);
            
            prepareStat.executeUpdate();
            
            session.setCurrentOutput(user + " deleted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
    * @brief add data to the database method
    * @param[in] user name of type String
    * @param[in] user password of type String
    */
    public static void addDataToDB(String user, String password, Session session) {

        try {
            String insertQueryStatement = "INSERT  IGNORE INTO "+dataBaseTableName+" VALUES  (?,?,?)";

            prepareStat = conn.prepareStatement(insertQueryStatement);
            prepareStat.setString(1, user);
            prepareStat.setString(2, password);
            prepareStat.setString(3, "0");

            // execute insert SQL statement
            prepareStat.executeUpdate();
            session.setCurrentOutput(user + " added successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
    * @brief get data from the Database method
    */
    
    public static User getRecordFromDB(String username) {
        User targetRecord = new User("","",false);
        try {
            // MySQL Select Query Tutorial
            String getQueryStatement = "SELECT * FROM "+dataBaseTableName;

            prepareStat = conn.prepareStatement(getQueryStatement);

            // Execute the Query, and get a java ResultSet
            ResultSet rs = prepareStat.executeQuery();

            // Let's iterate through the java ResultSet
            while (rs.next()) {
                String user = rs.getString("User");
                if (user.equals(username)) {
                    targetRecord.username = user;
                    targetRecord.password = decodePassword(rs.getString("Password"));
                    targetRecord.isSuper = rs.getBoolean("IsSuper");
                }
            
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return targetRecord;
    }
    
    /**
    * @brief decode password method
    * @param[in] user name as type String
    * @param[in] plain password of type String
    * @return true if the credentials are valid, otherwise false
    */
    public static boolean validateUser(String user, String pass){
        try {
            // MySQL Select Query Tutorial
            String getQueryStatement = "SELECT User, Password FROM "+dataBaseTableName;

            prepareStat = conn.prepareStatement(getQueryStatement);

            // Execute the Query, and get a java ResultSet
            ResultSet rs = prepareStat.executeQuery();

            // Let's iterate through the java ResultSet
            while (rs.next()) {
                if (user.equals(rs.getString("User")) && pass.equals(decodePassword(rs.getString("Password")))){
                    return true;
                }
            }
        } 
        
        catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }

    /**
    * @brief print a message on screen method
    * @param message of type String
    */
    public static void log(String message) {
        System.out.println(message);

    }
    
    public static void setSuper(String username, Boolean isSuper) {
        try {
            String insertQueryStatement = "UPDATE Users SET IsSuper = "+isSuper+" WHERE User = '"+username+"';";
            System.out.println(insertQueryStatement);
            prepareStat = conn.prepareStatement(insertQueryStatement);
            prepareStat.executeUpdate();
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static Boolean recordExists(String username) {
        Boolean exists = false;
        try {
            // MySQL Select Query Tutorial
            String getQueryStatement = "SELECT * FROM "+dataBaseTableName+" WHERE User = '"+username+"';";
            System.out.println(getQueryStatement);

            prepareStat = conn.prepareStatement(getQueryStatement);

            // Execute the Query, and get a java ResultSet
            ResultSet rs = prepareStat.executeQuery();

            // Let's iterate through the java ResultSet
            while (rs.next()) {
                String user = rs.getString("User");
                if (user.equals(username)) {
                    exists = true;
                }
            
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exists;
    }
}

