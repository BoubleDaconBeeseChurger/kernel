/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.remoteshell;

import java.io.BufferedReader;
import java.io.File;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;

/**
 *
 * @author ntu-admin
 */
public class main {
    private static final int PORT = 2222;
    
    static boolean validateToken(String token, String[] dataset) { //takes token and see if it is found in dataset/returns true if a match is found
        boolean result = false;
        for(String i : dataset) {
                if (token.equals(i)) {
                    result = true;
                }
            }
        return result;
    };
    
    static String filterPath(String inputtedPath) { //shortens file path to just the most local directory
        String filteredPath = "";
        Pattern pathSection = Pattern.compile("^/|(/[\\w-]+)+$", Pattern.CASE_INSENSITIVE);
        Matcher testPath = pathSection.matcher(inputtedPath);
        
        while (testPath.find()) {
            filteredPath = testPath.group(1) + "/";
        }
        
        return filteredPath;
    };
    
    static String filterPost(String inputtedPost) {
        String filteredPost = inputtedPost.substring(inputtedPost.indexOf("=")+1);
        return filteredPost.trim();
    }
    
    static String formatTerminalLine(String user, String dirPath, String command) {
        String formattedLine = user + ":~" + dirPath + "$ " + command;
        return formattedLine;
    }
    
    static List<String> returnListValue(List<String> copyList) {
        List<String> newList = new ArrayList<String>(copyList);
        return newList;
    }
    
    static String returnStringValue(String copyString) {
        String newString = copyString;
        return newString;
    }
    
    static void refreshHTTP(PrintWriter out, Session currentSession) {
        out.println("HTTP/1.0 200 OK");
        out.println("Content-Type: text/html; charset=utf-8");
        out.println("Server: MINISERVER");
        // this blank line signals the end of the headers
        out.println("");
        // Send the HTML page               
        out.println("<H1>Remote Shell</H1>");
        out.println("<form name=\"input\" action=\"imback\" method=\"post\">");
        out.println(filterPath(currentSession.currentLocation) + "$" + "<input type=\"text\" name=\"user\"><input type=\"submit\" value=\"Submit\"></form>");
        for (int i = currentSession.history.size()-1; i > 0; i--) {
            out.println("<p style=\"margin-left:5px\">"+ currentSession.history.get(i).getTerminalLine() +"</p>");
            out.println("<p style=\"margin-left:5px\">"+ currentSession.history.get(i).getTerminalOutput() +"</p>");
        }
    }
    
    static String getPostData(BufferedReader reader) throws IOException {
        String line = null;
                
        // looks for post data
        int postDataI = -1;
        while ((line = reader.readLine()) != null && (line.length() != 0)) {
            if (line.contains("Content-Length:")) {
                postDataI = Integer.parseInt(line.substring(
                        line.indexOf("Content-Length:") + 16,
                        line.length()));
            }
        }
        String postData = "";
        for (int i = 0; i < postDataI; i++) {
            int intParser = reader.read();
            postData += (char) intParser;
        }
        // replace + with " "
        int index=postData.indexOf('+');
        while (index>-1) {
            postData = postData.substring(0, index) + ' ' + postData.substring(index + 1);
            index = postData.indexOf('+');
        }

        return filterPost(postData);
    }
    
    static Boolean allCharsValid(String [] parsedInput, Pattern invalidChars, Session session){
        Boolean valid = true;
        for(String token : parsedInput) {
            Matcher checkChars = invalidChars.matcher(token);
            if (checkChars.find()) {
                session.setCurrentOutput("Error: Invalid characters detected (£$!%;).");
                valid = false;
            }
        }
        return valid;
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        try {
            ServerSocket server = new ServerSocket(PORT);
            System.out.println("Echo Server listening port: " + PORT);

            String[] externalCommands = new String[] {"ls", "cp", "mv", "mkdir", "rmdir", "ps", "which"};
            String[] builtInCommands = new String[] {"super", "addUser", "delUser", "chPass", "chUserType", "whoAmI", "move", "copy", "login", "logoff", "cd", "showDir", "help"};
            Pattern invalidChars = Pattern.compile("[£$!%;]");
            
            User currentUser = new User("root","root",true);
            Session currentSession = new Session(currentUser);
            mySQLDB.makeJDBCConnection();
            
            var processBuilder = new ProcessBuilder();     //<<<<<<<<<<
            
            

            boolean running = true;

            while (running) {
                // HTTP Server
                Socket socket = server.accept();
                PrintWriter out = new PrintWriter(socket.getOutputStream());
                // Take user input from Server
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                // Setting directory for processess
                processBuilder.directory(new File(currentSession.currentLocation));
                // Prepare user input
                currentSession.currentOutput = "";
                String postData = getPostData(reader);
                String[] parsedInput = postData.split(" ");
                //before sanitizing (validating input)  
                running = allCharsValid(parsedInput, invalidChars, currentSession); 
                //this part tries external commands -- does not work
                Boolean commandFound = false;
                for(String command : externalCommands) {
                    if (command.equals(parsedInput[0])) {
                        processBuilder.command(parsedInput);
                        var process = processBuilder.start();
                        try (var reader2 = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                            String line;
                            String concatLine = "";
                            while ((line = reader2.readLine()) != null) {
                                concatLine = concatLine + " " + line;
                            }
                            currentSession.setCurrentOutput(concatLine);
                        }
                        commandFound = true;
                    }
                }
                // Tries built in commands
                for(String command : builtInCommands) {
                    if (command.equals(parsedInput[0])) {
                        BuiltInCommand builtIn = new BuiltInCommand(parsedInput[0], parsedInput, currentSession, currentUser);
                        commandFound = true;
                    }
                }    
                if (!commandFound && !parsedInput[0].isEmpty()) {
                    currentSession.setCurrentOutput("Error: Command " + parsedInput[0] + " was not found.");
                }
                // Update objects and remote shell
                currentSession.addToHistory(currentUser.username, currentSession.currentLocation, postData.substring(postData.lastIndexOf("=") + 1));
                refreshHTTP(out, currentSession);
                out.close();
                socket.close();
            }
                server.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
