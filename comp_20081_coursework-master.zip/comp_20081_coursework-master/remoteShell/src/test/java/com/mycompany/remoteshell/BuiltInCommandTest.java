/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.remoteshell;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ntu-admin
 */
public class BuiltInCommandTest {
    
    public BuiltInCommandTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }

    /**
     * Test of superCommands method, of class BuiltInCommand.
     */
    @Test
    public void testSuperCommands() {
        System.out.println("superCommands");
        String command = "";
        String[] arguments = null;
        Session session = null;
        User user = null;
        BuiltInCommand instance = null;
        instance.superCommands(command, arguments, session, user);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showUsers method, of class BuiltInCommand.
     */
    @Test
    public void testShowUsers1() { //
        String correctAnswer = " kian will";
        System.out.println("showUsers1");
        Session session = new Session(new User("test","test",false));
        mySQLDB.makeJDBCConnection();
        BuiltInCommand.showUsers(session);
        String result = session.currentOutput;
        System.out.println("result __________---------->> "+result);
        assertEquals(correctAnswer, result);     //
    }
    @Test
    public void testShowUsers2() {
        String correctAnswer = " kian will";
        for (int i = 0; i<98; i++) {
            correctAnswer = correctAnswer + " TEST";
        }
        System.out.println("showUsers2");
        Session session = new Session(new User("test","test",false));
        mySQLDB.makeJDBCConnection();
        BuiltInCommand.showUsers(session);
        String result = session.currentOutput;
        System.out.println("result ---------->> "+result);
        assertEquals(correctAnswer, result);     //
    }

    /**
     * Test of addUser method, of class BuiltInCommand.
     */
    @Test
    public void testAddUser1() {
        System.out.println("addUser1");
        String user = "";
        User newUser = new User("root","root",true);
        Session session = new Session(newUser);
        mySQLDB.makeJDBCConnection();
        BuiltInCommand.addUser(newUser.username, newUser.password, session);
        User qUser = mySQLDB.getRecordFromDB(newUser.username);
        assertEquals(qUser.username, newUser.username);
    }

    /**
     * Test of chPass method, of class BuiltInCommand.
     */
    @Test
    public void testChPass1() { //
        String firstPass =  "pass1";
        String secondPass = "pass2";
        System.out.println("chPass1");
        User newUser = new User("root2",firstPass,true);
        Session session = new Session(newUser);
        mySQLDB.makeJDBCConnection();
        BuiltInCommand.addUser(newUser.username, newUser.password, session);
        BuiltInCommand.chPass(firstPass, secondPass, session, newUser);
        User qUser = mySQLDB.getRecordFromDB(newUser.username);
        assertEquals(qUser.password, secondPass);
    }

    /**
     * Test of chUserType method, of class BuiltInCommand.
     */
    @Test
    public void testChUserType1() {//
        System.out.println("chUserType1");
        Boolean initialType = false;
        System.out.println("Initial type: "+initialType);
        User newUser = new User("Chris","pass",initialType);
        User superUser = new User("","",true);
        Session session = new Session(newUser);
        mySQLDB.makeJDBCConnection();
        BuiltInCommand.addUser(newUser.username, newUser.password, session);
        BuiltInCommand.chUserType(newUser.username, session, superUser);
        User qUser = mySQLDB.getRecordFromDB(newUser.username);
        assertNotEquals(qUser.isSuper, initialType);
    }
    

    /**
     * Test of logoff method, of class BuiltInCommand.
     */
    @Test
    public void testLogoff() { //
        System.out.println("logoff");
        String firstUser = "user";
        User user = new User(firstUser,"",false);
        Session session = new Session(user);
        BuiltInCommand.logoff(session, user);
        assertNotEquals(firstUser, user.username);
    }

    /**
     * Test of delUser method, of class BuiltInCommand.
     */
    @Test
    public void testDelUser() {//
        User user = new User("del", "", false);
        User superUser = new User("","",true);
        Session session = new Session(user);
        mySQLDB.makeJDBCConnection();
        BuiltInCommand.addUser(user.username, user.password, session);
        BuiltInCommand.delUser(user.username, session, superUser);
        assertEquals(false, mySQLDB.recordExists(user.username));
    }

    /**
     * Test of whoAmI method, of class BuiltInCommand.
     */
    @Test
    public void testWhoAmI() {
        System.out.println("whoAmI");
        String username = "whoAmI";
        User user = new User(username,"",false);
        Session session = new Session(user);
        BuiltInCommand.whoAmI(user, session);
        assertEquals(username, session.currentOutput);
    }

    /**
     * Test of cd method, of class BuiltInCommand.
     */
    @Test
    public void testCd1() {
        System.out.println("cd");
        String target = "testDir";
        User user = new User("guest","",false);
        Session session = new Session(user);
        String initialLocation = session.currentLocation;
        BuiltInCommand.cd(target, session);
        assertEquals(initialLocation+"/"+target, session.currentLocation);
    }

    /**
     * Test of showDir method, of class BuiltInCommand.
     */
    @Test
    public void testShowDir() {
        System.out.println("showDir");
        User user = new User("guest","",false);
        Session session = new Session(user);
        BuiltInCommand.showDir(session);
        assertEquals(session.currentOutput, session.currentLocation);
    }

    /**
     * Test of copy method, of class BuiltInCommand.
     */
    @Test
    public void testCopy() throws IOException {
        System.out.println("copy");
        String source = "source.txt";
        String target = "target.txt";
        User user = new User("guest","",false);
        Session session = new Session(user);
        BuiltInCommand.copy(source,target,session);
        
        String strSource = session.currentLocation+"/"+source;
        String strTarget = session.currentLocation+"/"+target;
        Path pathSource = Paths.get(strSource);
        Path pathTarget = Paths.get(strTarget);
        byte[] sourceByte = Files.readAllBytes(pathSource);
        byte[] targetByte = Files.readAllBytes(pathTarget);
        String sourceContent = new String(sourceByte);
        String targetContent = new String(targetByte);
        System.out.println("src-> "+sourceContent);
        System.out.println("trgt-> "+targetContent);
        assertEquals(sourceContent, targetContent);
     }

    /**
     * Test of move method, of class BuiltInCommand.
     */
    @Test
    public void testMove() throws IOException {
        System.out.println("move");
        String source = "source.txt";
        String target = "target.txt";
        User user = new User("guest","",false);
        Session session = new Session(user);
        
        String strSource = session.currentLocation+"/"+source;
        Path pathSource = Paths.get(strSource);
        byte[] sourceByte = Files.readAllBytes(pathSource);
        String sourceContent = new String(sourceByte);
        System.out.println("src-> "+sourceContent);
        
        BuiltInCommand.move(source, target, session);
        
        String strTarget = session.currentLocation+"/"+target;
        Path pathTarget = Paths.get(strTarget);
        byte[] targetByte = Files.readAllBytes(pathTarget);
        String targetContent = new String(targetByte);
        System.out.println("trgt-> "+targetContent);
        
        Boolean pass = true;
        
        File postMove = new File(session.currentLocation+"/"+source);
        if(postMove.exists() && !postMove.isDirectory()) {
            pass = false;
        }
        if (!(sourceContent.equals(targetContent))) {
            pass = false;
        }
        assertEquals(true, pass);
    }

    /**
     * Test of login method, of class BuiltInCommand.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        User user = new User("guest","",false);
        Session session = new Session(user);
        User targetUser = new User("kian","password321",true);
        mySQLDB.makeJDBCConnection();
        BuiltInCommand.login(targetUser.username,targetUser.password,session,user);
        assertEquals(targetUser.username,user.username);
    }    
}
