/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.remoteshell;

/**
 *
 * @author ntu-user
 */
public class ExternalCommand {
    String[] validCommands = new String[] {"ls", "cp", "mv", "mkdir", "rmdir", "ps", "which"};
}
